
public class ResistanceCalculationCommand {

}
