public interface ResultTable {
    void display(double[] values, String[] columnNames, String tableName);
    }