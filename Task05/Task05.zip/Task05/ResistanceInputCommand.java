
public class ResistanceInputCommand {

}
