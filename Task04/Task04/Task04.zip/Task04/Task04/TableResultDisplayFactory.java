package Task04;


 /**
 * The class Table result display factory
 */ 
public class TableResultDisplayFactory {


/** 
 *
 * It is a constructor. 
 *
 */
    public TableResultDisplayFactory() { 

    }
    
}
