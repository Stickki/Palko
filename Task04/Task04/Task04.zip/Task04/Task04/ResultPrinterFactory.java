package Task04;

interface ResultPrinterFactory {
    
}
