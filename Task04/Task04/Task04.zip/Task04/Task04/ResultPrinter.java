package Task04;


interface ResultPrinter {
    
}
