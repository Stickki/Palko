
package Task04;

class results {

    static void add(ResistanceResult result) {
        throw new UnsupportedOperationException("Не пiдтримується!");
    }
    
}
