package Task04;


class List<T> {
    
}
