package Task04;


public interface FactoryMethod {
    Resistance createResistance();
}

