package Task04;


 /**
 * The class Table result display extends result display
 */ 
public class TableResultDisplay extends ResultDisplay {


/** 
 *
 * Table result display
 *
 * @param result  the result. 
 * @return public
 */
    public TableResultDisplay(ResistanceResult result) { 

    }



    
}
