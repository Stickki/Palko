package Task04;

class ResistanceResult {

    Object[] getResistance3() {
        throw new UnsupportedOperationException("Не пiдтримується!"); 
    }

    Object[] getResistance1() {
        throw new UnsupportedOperationException("Не пiдтримується!"); 
    }

    Object[] getTotalResistance() {
        throw new UnsupportedOperationException("Не пiдтримується!"); 
    }

    Object[] getResistance2() {
        throw new UnsupportedOperationException("Не пiдтримується!"); 
    }

    double getVoltage1() {
        throw new UnsupportedOperationException("Не пiдтримується!"); 
    }

    double getVoltage2() {
        throw new UnsupportedOperationException("Не пiдтримується!"); 
    }

    double getVoltage3() {
        throw new UnsupportedOperationException("Не пiдтримується!");
    }

    double getCurrent() {
        throw new UnsupportedOperationException("Не пiдтримується!"); 
    }
}

