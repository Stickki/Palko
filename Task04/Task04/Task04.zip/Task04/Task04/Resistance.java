package Task04;

class Resistance {

    double getResistance() {
        throw new UnsupportedOperationException("Не пiдтримується!");
    }
}
