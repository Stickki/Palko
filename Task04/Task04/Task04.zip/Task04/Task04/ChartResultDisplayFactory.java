package Task04;


 /**
 * The class Chart result display factory extends table result display factory
 */ 
public class ChartResultDisplayFactory extends TableResultDisplayFactory {


/** 
 *
 * Chart result display factory
 *
 * @return public
 */
    public ChartResultDisplayFactory() { 

    }
    
}