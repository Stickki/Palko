package Task04;


 /**
 * The class Chart result display extends result display
 */ 
public class ChartResultDisplay extends ResultDisplay {


/** 
 *
 * Chart result display
 *
 * @param result  the result. 
 * @return public
 */
    public ChartResultDisplay(ResistanceResult result) { 

    }



    
}
