package Task04;



 /**
 * The class Abstract resistance factory implements factory method
 */ 
public abstract class ResistanceFactory implements FactoryMethod {


/** 
 *
 * Resistance factory
 *
 * @return public
 */
    public ResistanceFactory() { 

    }
    
}
