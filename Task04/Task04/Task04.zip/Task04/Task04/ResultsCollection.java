package Task04;

class ResultsCollection {
    
}
