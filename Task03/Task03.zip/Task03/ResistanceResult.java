class ResistanceResult {

    Object[] getTotalResistance() {
        throw new UnsupportedOperationException("Не пiдтримується!"); 
    }

    Object[] getResistance1() {
        throw new UnsupportedOperationException("Не пiдтримується!");
    }

    Object[] getResistance2() {
        throw new UnsupportedOperationException("Не пiдтримується!"); 
    }

    Object[] getResistance3() {
        throw new UnsupportedOperationException("Не пiдтримується!"); 
    }
    
}
