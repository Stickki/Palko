public interface ResistanceCalculatorDisplay {
    void display8YearResistance(double resistance);
    void display16YearResistance(double resistance);
    }