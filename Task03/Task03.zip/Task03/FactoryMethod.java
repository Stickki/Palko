
public interface FactoryMethod {
    Resistance createResistance();
}

