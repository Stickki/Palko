public class TableResultDisplayFactory {


    /** 
     *
     * It is a constructor. 
     *
     */
        public TableResultDisplayFactory() { 
    
        }
        
    }
