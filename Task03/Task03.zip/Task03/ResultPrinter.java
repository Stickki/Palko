interface ResultPrinter {
    
}
