public class ChartResultDisplayFactory extends TableResultDisplayFactory {


    /** 
     *
     * Chart result display factory
     *
     * @return public
     */
        public ChartResultDisplayFactory() { 
    
        }
        
    }