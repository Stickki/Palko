interface ResultPrinterFactory {
    
}
