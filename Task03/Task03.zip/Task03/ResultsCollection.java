class ResultsCollection {
    
}
