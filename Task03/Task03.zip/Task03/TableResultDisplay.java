public class TableResultDisplay extends ResultDisplay {


    /** 
     *
     * Table result display
     *
     * @param result  the result
     * @return public
     */
        public TableResultDisplay(ResistanceResult result) { 
    
        }
        
    }