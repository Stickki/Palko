/**
 * The class Array list< t>
 */ 
public class ArrayList<T> {


    /** 
     *
     * Array list
     *
     * @return public
     */
        public ArrayList() { 
    
        }
        void add(TableResultDisplayFactory tableResultDisplayFactory) {
            throw new UnsupportedOperationException("Не пiдтримується!");
        }
        
    }
    
    