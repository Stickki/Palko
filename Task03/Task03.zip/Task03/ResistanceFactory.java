public abstract class ResistanceFactory implements FactoryMethod {


    /** 
     *
     * Resistance factory
     *
     * @return public
     */
        public ResistanceFactory() { 
    
        }
        
    }