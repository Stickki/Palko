class Resistance {

    static Resistance resistance;  

    static String getValue() {
        throw new UnsupportedOperationException("Не пiдтримується!");
    }
}
